

public class Oper {
	User us = null;
	LoginFrame lf = null;
	JoinFrame jf = null;
	MainFrame mf = null;
	CheckFrame ckf = null;
	ChangeFrame chf = null;
	
	public static void main(String[] args)
	{
		Oper opr = new Oper();
		
		opr.lf= new LoginFrame();
	}
}
